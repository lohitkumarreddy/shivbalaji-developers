export default function Admin() {
  return (
    <div className="max-w-6xl mx-auto px-6 py-12">
      <h1 className="text-2xl font-semibold">Admin Dashboard</h1>
      <p className="text-gray-600 mt-2">Manage listings, projects, and leads from here.</p>
      <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="glass p-4 rounded">Listings (CRUD)</div>
        <div className="glass p-4 rounded">Projects (CRUD)</div>
        <div className="glass p-4 rounded">Leads</div>
      </div>
    </div>
  )
}
