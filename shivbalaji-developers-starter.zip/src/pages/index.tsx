import AnimatedHero from '../components/AnimatedHero'
import PropertyCard from '../components/PropertyCard'
import prismaClient from '../lib/db'

export default function Home({ listings }: any) {
  return (
    <div className="max-w-6xl mx-auto px-6 py-12">
      <AnimatedHero />

      <section className="mt-10">
        <h2 className="text-2xl font-semibold">Featured Listings</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6">
          {listings.map((l: any) => <PropertyCard key={l.id} listing={l} />)}
        </div>
      </section>
    </div>
  )
}

export async function getServerSideProps() {
  const listings = await prismaClient.listing.findMany({ take: 6 })
  return { props: { listings: JSON.parse(JSON.stringify(listings)) } }
}
